/**
 * ioBroker Blustream ACM200 Adapter
 * Controls Blustream ACM200 matrix switches for audio/video distribution over IP
 *
 * File: main.js - Main adapter file
 */

'use strict';

const utils = require('@iobroker/adapter-core');
const net = require('net');

class BlustreamAcm200 extends utils.Adapter {
    constructor(options) {
        super({
            ...options,
            name: 'blustream-acm200',
        });

        this.on('ready', this.onReady.bind(this));
        this.on('stateChange', this.onStateChange.bind(this));
        this.on('unload', this.onUnload.bind(this));

        // Default settings
        this.host = '192.168.0.225'; // Default IP for ACM200
        this.port = 23; // Default Telnet port
        this.pollInterval = 30000; // Poll every 30 seconds
        this.timeout = 5000; // 5 second timeout for commands
        this.client = null;
        this.pollTimer = null;
        this.reconnectTimer = null;
        this.connected = false;
        this.receiverStates = {};
        this.transmitterStates = {};
        this.connectionInProgress = false;
    }

    /**
     * Initialize the adapter
     */
    async onReady() {
        // Reset the connection indicator at startup
        this.setState('info.connection', false, true);

        // Get configuration from admin settings
        this.host = this.config.host || this.host;
        this.port = this.config.port || this.port;
        this.pollInterval = this.config.pollInterval || this.pollInterval;
        this.timeout = this.config.timeout || this.timeout;

        // Create root objects - FIXED: Using object with name property
        await this.createDeviceAsync('system', { name: 'Blustream ACM200 System' });
        await this.createChannelAsync('system', 'status', { name: 'System Status' });
        await this.createChannelAsync('system', 'commands', { name: 'System Commands' });

        // Create system states
        await this.createStateAsync('system.status', 'connected', {
            name: 'Connection Status',
            type: 'boolean',
            role: 'indicator.connection',
            read: true,
            write: false,
        });

        await this.createStateAsync('system.status', 'lastUpdate', {
            name: 'Last Update',
            type: 'string',
            role: 'date',
            read: true,
            write: false,
        });

        await this.createStateAsync('system.commands', 'refresh', {
            name: 'Refresh All',
            type: 'boolean',
            role: 'button',
            read: false,
            write: true,
        });

        // Initialize folders for transmitters and receivers - FIXED: Using object with name property
        await this.createDeviceAsync('transmitters', { name: 'Video Sources (Transmitters)' });
        await this.createDeviceAsync('receivers', { name: 'Displays (Receivers)' });

        // Subscribe to states
        this.subscribeStates('system.commands.refresh');
        this.subscribeStates('receivers.*.route');

        // Start connection to ACM200
        this.connectTelnet();
    }

    /**
     * Handle state changes
     * @param {string} id - State ID
     * @param {object} state - State object
     */
    onStateChange(id, state) {
        if (state && !state.ack) {
            // Handle manual refresh
            if (id === `${this.namespace}.system.commands.refresh`) {
                this.log.info('Manual refresh triggered');
                this.refreshDeviceStatus();
                return;
            }

            // Handle routing changes
            if (id.startsWith(`${this.namespace}.receivers.`) && id.endsWith('.route')) {
                const receiverId = id.split('.')[2];
                const transmitterId = state.val;
                
                if (receiverId && transmitterId) {
                    this.log.info(`Routing transmitter ${transmitterId} to receiver ${receiverId}`);
                    this.routeVideo(transmitterId, receiverId);
                }
            }
        }
    }

    /**
     * Clean up on adapter unload
     */
    onUnload(callback) {
        try {
            // Clear timers
            if (this.pollTimer) {
                clearTimeout(this.pollTimer);
                this.pollTimer = null;
            }
            if (this.reconnectTimer) {
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = null;
            }

            // Close Telnet connection
            if (this.client) {
                this.client.destroy();
                this.client = null;
            }

            this.log.info('Cleaned up everything');
            callback();
        } catch (e) {
            callback();
        }
    }

    /**
     * Connect to the Blustream ACM200 via Telnet
     */
    connectTelnet() {
        if (this.connectionInProgress) return;
        this.connectionInProgress = true;

        this.log.info(`Connecting to ACM200 at ${this.host}:${this.port}`);

        // Close existing connection if open
        if (this.client) {
            this.client.destroy();
            this.client = null;
        }

        // Create new connection
        this.client = new net.Socket();
        let buffer = '';

        // Set timeout
        this.client.setTimeout(this.timeout);

        // Handle connection
        this.client.on('connect', () => {
            this.log.info('Connected to ACM200');
            this.connected = true;
            this.setState('info.connection', true, true);
            this.connectionInProgress = false;

            // Initialize device status
            this.refreshDeviceStatus();

            // Start polling
            this.startPolling();
        });

        // Handle data received
        this.client.on('data', (data) => {
            // Append received data to buffer
            buffer += data.toString();

            // Process complete messages
            let endIndex;
            while ((endIndex = buffer.indexOf('\n')) !== -1) {
                const line = buffer.substring(0, endIndex).trim();
                buffer = buffer.substring(endIndex + 1);

                // Process the line
                this.processResponse(line);
            }
        });

        // Handle errors
        this.client.on('error', (error) => {
            this.log.error(`Connection error: ${error.message}`);
            this.connectionInProgress = false;
            this.cleanup();
        });

        // Handle timeout
        this.client.on('timeout', () => {
            this.log.warn('Connection timeout');
            this.connectionInProgress = false;
            this.cleanup();
        });

        // Handle connection close
        this.client.on('close', () => {
            if (this.connected) {
                this.log.info('Connection closed');
                this.cleanup();
            }
        });

        // Connect
        this.client.connect(this.port, this.host, () => {
            // This will trigger the 'connect' event handler above
        });
    }

    /**
     * Start polling for device status updates
     */
    startPolling() {
        if (this.pollTimer) {
            clearTimeout(this.pollTimer);
        }

        this.pollTimer = setTimeout(() => {
            if (this.connected) {
                this.refreshDeviceStatus();
            }
            this.startPolling();
        }, this.pollInterval);
    }

    /**
     * Clean up connection resources
     */
    cleanup() {
        this.connected = false;
        this.setState('info.connection', false, true);

        if (this.client) {
            this.client.destroy();
            this.client = null;
        }

        // Retry connection after delay
        if (!this.reconnectTimer) {
            this.reconnectTimer = setTimeout(() => {
                this.reconnectTimer = null;
                this.connectTelnet();
            }, 30000); // Retry every 30 seconds
        }
    }

    /**
     * Send a command to the ACM200
     * @param {string} command - Command to send
     * @param {function} callback - Optional callback function
     */
    sendCommand(command, callback) {
        if (!this.connected || !this.client) {
            this.log.warn(`Cannot send command, not connected: ${command}`);
            if (callback) callback(new Error('Not connected'));
            return;
        }

        this.log.debug(`Sending command: ${command}`);
        this.client.write(command + '\n', 'utf8', (err) => {
            if (err) {
                this.log.error(`Error sending command: ${err.message}`);
                if (callback) callback(err);
            } else if (callback) {
                callback(null);
            }
        });
    }

    /**
     * Process response from the ACM200
     * @param {string} line - Response line
     */
    processResponse(line) {
        this.log.debug(`Received response: ${line}`);

        // Parse status response
        if (line.includes('IP Control Box ACM200 Status Info')) {
            // Process system status response
            this.processStatusInfo(line);
        } else if (line.includes('Output Info')) {
            // Process receiver info
            this.processReceiverInfo(line);
        } else if (line.includes('Input Info')) {
            // Process transmitter info
            this.processTransmitterInfo(line);
        }
    }

    /**
     * Process system status information
     * @param {string} data - Status data
     */
    processStatusInfo(data) {
        // Update system information
        this.setState('system.status.lastUpdate', new Date().toISOString(), true);

        // Extract firmware version
        const fwMatch = data.match(/FW Version: ([\d.]+)/);
        if (fwMatch) {
            this.setStateAsync('system.status.firmwareVersion', { val: fwMatch[1], ack: true });
        }

        // Extract transmitter and receiver counts
        // This is a simplification - you would need to parse the actual response format
        // based on the ACM200 documentation
        const inMatch = data.match(/In EDID IP NET\/Sig/);
        const outMatch = data.match(/Out FromIn IP NET\/HDMI Res Mode/);

        if (inMatch && outMatch) {
            // Now we know we have a valid status response
            // Parse transmitters and receivers
            this.parseTransmitters(data);
            this.parseReceivers(data);
        }
    }

    /**
     * Parse transmitter information from status response
     * @param {string} data - Status data
     */
    parseTransmitters(data) {
        const lines = data.split('\n');
        const startIdx = lines.findIndex(line => line.includes('In EDID IP NET/Sig'));
        
        if (startIdx === -1) return;
        
        let i = startIdx + 1;
        while (i < lines.length && !lines[i].includes('Out FromIn')) {
            const line = lines[i].trim();
            const parts = line.split(/\s+/);
            
            if (parts.length >= 4 && /^\d+$/.test(parts[0])) {
                const id = parts[0].padStart(3, '0');
                const edid = parts[1];
                const ip = parts[2];
                const status = parts[3];
                
                // Create or update transmitter
                this.createTransmitter(id, ip, edid, status);
            }
            
            i++;
        }
    }

    /**
     * Parse receiver information from status response
     * @param {string} data - Status data
     */
    parseReceivers(data) {
        const lines = data.split('\n');
        const startIdx = lines.findIndex(line => line.includes('Out FromIn IP NET/HDMI'));
        
        if (startIdx === -1) return;
        
        let i = startIdx + 1;
        while (i < lines.length && !lines[i].includes('LAN DHCP')) {
            const line = lines[i].trim();
            const parts = line.split(/\s+/);
            
            if (parts.length >= 5 && /^\d+$/.test(parts[0])) {
                const id = parts[0].padStart(3, '0');
                const currentTx = parts[1].padStart(3, '0');
                const ip = parts[2];
                const status = parts[3];
                const resolution = parts[4];
                
                // Create or update receiver
                this.createReceiver(id, ip, currentTx, status, resolution);
            }
            
            i++;
        }
    }

    /**
     * Process transmitter information
     * @param {string} data - Transmitter data
     */
    processTransmitterInfo(data) {
        // Extract transmitter ID
        const idMatch = data.match(/In Net Sig Ver EDID Aud MCast Name\s+(\d+)/);
        if (!idMatch) return;

        const id = idMatch[1].padStart(3, '0');
        
        // Extract other details
        const nameMatch = data.match(/Name\s+(.+)$/m);
        const ipMatch = data.match(/IP\s+(.+)$/m);
        const statusMatch = data.match(/Net\s+(\w+)/);
        
        if (nameMatch && ipMatch && statusMatch) {
            const name = nameMatch[1].trim();
            const ip = ipMatch[1].trim();
            const status = statusMatch[1] === 'On';
            
            // Update transmitter info
            this.createTransmitter(id, ip, '', status, name);
        }
    }

    /**
     * Process receiver information
     * @param {string} data - Receiver data
     */
    processReceiverInfo(data) {
        // Extract receiver ID
        const idMatch = data.match(/Out Net HPD Ver Mode Res Rotate Name\s+(\d+)/);
        if (!idMatch) return;

        const id = idMatch[1].padStart(3, '0');
        
        // Extract other details
        const nameMatch = data.match(/Name\s+(.+)$/m);
        const ipMatch = data.match(/IP\s+(.+)$/m);
        const statusMatch = data.match(/Net\s+(\w+)/);
        const sourceMatch = data.match(/Fr Vid\/Aud\/IR_\/Ser\/USB\/CEC\s+(\d+)/);
        
        if (nameMatch && ipMatch && statusMatch && sourceMatch) {
            const name = nameMatch[1].trim();
            const ip = ipMatch[1].trim();
            const status = statusMatch[1] === 'On';
            const source = sourceMatch[1].padStart(3, '0');
            
            // Update receiver info
            this.createReceiver(id, ip, source, status, '', name);
        }
    }

    /**
     * Create or update a transmitter object
     * @param {string} id - Transmitter ID
     * @param {string} ip - IP address
     * @param {string} edid - EDID setting
     * @param {boolean|string} status - Connection status
     * @param {string} name - Optional name
     */
    async createTransmitter(id, ip, edid, status, name) {
        const txId = `transmitters.${id}`;
        let statusBool = false;
        
        if (typeof status === 'string') {
            statusBool = status.includes('On');
        } else {
            statusBool = !!status;
        }

        // Create device if it doesn't exist
        if (!this.transmitterStates[id]) {
            this.transmitterStates[id] = {
                id,
                ip,
                status: statusBool,
                edid,
                name: name || `Transmitter ${id}`
            };

            // FIXED: Using object with name property
            await this.createChannelAsync(txId, '', { name: this.transmitterStates[id].name });
            
            // Create states - NOTE: stateName must be a string, not an object
            await this.createStateAsync(txId, 'id', {
                name: 'Transmitter ID',
                type: 'string',
                role: 'info.name',
                read: true,
                write: false,
                def: id
            });

            await this.createStateAsync(txId, 'name', {
                name: 'Transmitter Name',
                type: 'string',
                role: 'info.name',
                read: true,
                write: true,
                def: this.transmitterStates[id].name
            });

            await this.createStateAsync(txId, 'ip', {
                name: 'IP Address',
                type: 'string',
                role: 'info.ip',
                read: true,
                write: false
            });

            await this.createStateAsync(txId, 'connected', {
                name: 'Connected',
                type: 'boolean',
                role: 'indicator.connection',
                read: true,
                write: false
            });

            await this.createStateAsync(txId, 'edid', {
                name: 'EDID Setting',
                type: 'string',
                role: 'info',
                read: true,
                write: false
            });

            await this.createStateAsync(txId, 'previewUrl', {
                name: 'Preview Image URL',
                type: 'string',
                role: 'url',
                read: true,
                write: false
            });
        }

        // Update states
        await this.setStateAsync(`${txId}.id`, { val: id, ack: true });
        await this.setStateAsync(`${txId}.ip`, { val: ip, ack: true });
        await this.setStateAsync(`${txId}.connected`, { val: statusBool, ack: true });
        
        if (edid) {
            await this.setStateAsync(`${txId}.edid`, { val: edid, ack: true });
        }
        
        if (name) {
            await this.setStateAsync(`${txId}.name`, { val: name, ack: true });
        }
        
        // Generate a preview URL - this would be replaced with actual image URL from your ACM200
        // The actual implementation would depend on how your system obtains preview images
        const previewUrl = `/blustream-acm200/preview/tx/${id}`;
        await this.setStateAsync(`${txId}.previewUrl`, { val: previewUrl, ack: true });

        // Update our internal state
        this.transmitterStates[id] = {
            ...this.transmitterStates[id],
            ip,
            status: statusBool,
            edid,
            name: name || this.transmitterStates[id].name
        };
    }

    /**
     * Create or update a receiver object
     * @param {string} id - Receiver ID
     * @param {string} ip - IP address
     * @param {string} currentTx - Current transmitter ID
     * @param {boolean|string} status - Connection status
     * @param {string} resolution - Output resolution
     * @param {string} name - Optional name
     */
    async createReceiver(id, ip, currentTx, status, resolution, name) {
        const rxId = `receivers.${id}`;
        let statusBool = false;
        
        if (typeof status === 'string') {
            statusBool = status.includes('On');
        } else {
            statusBool = !!status;
        }

        // Create device if it doesn't exist
        if (!this.receiverStates[id]) {
            this.receiverStates[id] = {
                id,
                ip,
                status: statusBool,
                currentTx,
                resolution,
                name: name || `Receiver ${id}`
            };

            // FIXED: Using object with name property
            await this.createChannelAsync(rxId, '', { name: this.receiverStates[id].name });
            
            // Create states - NOTE: stateName must be a string, not an object
            await this.createStateAsync(rxId, 'id', {
                name: 'Receiver ID',
                type: 'string',
                role: 'info.name',
                read: true,
                write: false,
                def: id
            });

            await this.createStateAsync(rxId, 'name', {
                name: 'Receiver Name',
                type: 'string',
                role: 'info.name',
                read: true,
                write: true,
                def: this.receiverStates[id].name
            });

            await this.createStateAsync(rxId, 'ip', {
                name: 'IP Address',
                type: 'string',
                role: 'info.ip',
                read: true,
                write: false
            });

            await this.createStateAsync(rxId, 'connected', {
                name: 'Connected',
                type: 'boolean',
                role: 'indicator.connection',
                read: true,
                write: false
            });

            await this.createStateAsync(rxId, 'route', {
                name: 'Current Source',
                type: 'string',
                role: 'level',
                read: true,
                write: true
            });

            await this.createStateAsync(rxId, 'resolution', {
                name: 'Output Resolution',
                type: 'string',
                role: 'info',
                read: true,
                write: false
            });

            await this.createStateAsync(rxId, 'previewUrl', {
                name: 'Preview Image URL',
                type: 'string',
                role: 'url',
                read: true,
                write: false
            });
        }

        // Update states
        await this.setStateAsync(`${rxId}.id`, { val: id, ack: true });
        await this.setStateAsync(`${rxId}.ip`, { val: ip, ack: true });
        await this.setStateAsync(`${rxId}.connected`, { val: statusBool, ack: true });
        await this.setStateAsync(`${rxId}.route`, { val: currentTx, ack: true });
        
        if (resolution) {
            await this.setStateAsync(`${rxId}.resolution`, { val: resolution, ack: true });
        }
        
        if (name) {
            await this.setStateAsync(`${rxId}.name`, { val: name, ack: true });
        }
        
        // Generate a preview URL - this would be replaced with actual image URL from your ACM200
        // The actual implementation would depend on how your system obtains preview images
        const previewUrl = `/blustream-acm200/preview/rx/${id}`;
        await this.setStateAsync(`${rxId}.previewUrl`, { val: previewUrl, ack: true });

        // Update our internal state
        this.receiverStates[id] = {
            ...this.receiverStates[id],
            ip,
            status: statusBool,
            currentTx,
            resolution,
            name: name || this.receiverStates[id].name
        };
    }

    /**
     * Refresh the device status
     */
    refreshDeviceStatus() {
        if (!this.connected) return;
        
        // Get system status
        this.sendCommand('STATUS');
        
        // Get detailed information about transmitters and receivers
        // This will be handled based on your ACM200's command set
        
        // Update timestamp
        this.setState('system.status.lastUpdate', new Date().toISOString(), true);
    }

    /**
     * Route video from a transmitter to a receiver
     * @param {string} txId - Transmitter ID
     * @param {string} rxId - Receiver ID
     */
    routeVideo(txId, rxId) {
        if (!this.connected) {
            this.log.warn('Cannot route video, not connected');
            return;
        }

        // Format for routing command is OUT[RX]FR[TX]
        // Example: OUT001FR002 routes input 2 to output 1
        const command = `OUT${rxId.padStart(3, '0')}FR${txId.padStart(3, '0')}`;
        
        this.sendCommand(command, (err) => {
            if (err) {
                this.log.error(`Error routing video: ${err.message}`);
            } else {
                this.log.info(`Successfully routed TX ${txId} to RX ${rxId}`);
                
                // Update the state so it shows correctly in the UI
                this.setState(`receivers.${rxId}.route`, txId, true);
                
                // Also update our internal state
                if (this.receiverStates[rxId]) {
                    this.receiverStates[rxId].currentTx = txId;
                }
            }
        });
    }

    /**
     * Route video from a transmitter to all receivers
     * @param {string} txId - Transmitter ID
     */
    routeVideoToAll(txId) {
        if (!this.connected) {
            this.log.warn('Cannot route video, not connected');
            return;
        }

        // Format for routing command to all receivers is OUTALLFRXX
        // Example: OUTALL003 routes input 3 to all outputs
        const command = `OUTALL${txId.padStart(3, '0')}`;
        
        this.sendCommand(command, (err) => {
            if (err) {
                this.log.error(`Error routing video to all: ${err.message}`);
            } else {
                this.log.info(`Successfully routed TX ${txId} to all receivers`);
                
                // Update all receiver states
                for (const rxId in this.receiverStates) {
                    this.setState(`receivers.${rxId}.route`, txId, true);
                    this.receiverStates[rxId].currentTx = txId;
                }
            }
        });
    }
}

// @ts-ignore parent is a valid property on module
if (module.parent) {
    // Export the constructor in compact mode
    module.exports = (options) => new BlustreamAcm200(options);
} else {
    // otherwise start the instance directly
    new BlustreamAcm200();
}
